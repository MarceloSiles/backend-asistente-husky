console.log("Asistente Husky cargado correctamente.");
